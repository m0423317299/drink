﻿namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl品名1 = new System.Windows.Forms.Label();
            this.lbl品名2 = new System.Windows.Forms.Label();
            this.lbl品名3 = new System.Windows.Forms.Label();
            this.lbl品名4 = new System.Windows.Forms.Label();
            this.lbl品名5 = new System.Windows.Forms.Label();
            this.lbl售價1 = new System.Windows.Forms.Label();
            this.lbl售價2 = new System.Windows.Forms.Label();
            this.lbl售價3 = new System.Windows.Forms.Label();
            this.lbl售價4 = new System.Windows.Forms.Label();
            this.lbl售價5 = new System.Windows.Forms.Label();
            this.tb杯數1 = new System.Windows.Forms.TextBox();
            this.tb杯數2 = new System.Windows.Forms.TextBox();
            this.tb杯數3 = new System.Windows.Forms.TextBox();
            this.tb杯數4 = new System.Windows.Forms.TextBox();
            this.tb杯數5 = new System.Windows.Forms.TextBox();
            this.btn杯數1加 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.tb折數 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl訂單總價 = new System.Windows.Forms.Label();
            this.lbl折扣總價 = new System.Windows.Forms.Label();
            this.btn列印訂購單 = new System.Windows.Forms.Button();
            this.btn杯數2加 = new System.Windows.Forms.Button();
            this.btn杯數3加 = new System.Windows.Forms.Button();
            this.btn杯數4加 = new System.Windows.Forms.Button();
            this.btn杯數5加 = new System.Windows.Forms.Button();
            this.btn杯數1減 = new System.Windows.Forms.Button();
            this.btn杯數2減 = new System.Windows.Forms.Button();
            this.btn杯數3減 = new System.Windows.Forms.Button();
            this.btn杯數4減 = new System.Windows.Forms.Button();
            this.btn杯數5減 = new System.Windows.Forms.Button();
            this.btn第二件六折 = new System.Windows.Forms.Button();
            this.btn買三送一 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SaddleBrown;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(62, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "品名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SaddleBrown;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(269, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "售價";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.SaddleBrown;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(459, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "數量";
            // 
            // lbl品名1
            // 
            this.lbl品名1.AutoSize = true;
            this.lbl品名1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl品名1.Location = new System.Drawing.Point(62, 107);
            this.lbl品名1.Name = "lbl品名1";
            this.lbl品名1.Size = new System.Drawing.Size(62, 31);
            this.lbl品名1.TabIndex = 3;
            this.lbl品名1.Text = "紅茶";
            // 
            // lbl品名2
            // 
            this.lbl品名2.AutoSize = true;
            this.lbl品名2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl品名2.Location = new System.Drawing.Point(62, 179);
            this.lbl品名2.Name = "lbl品名2";
            this.lbl品名2.Size = new System.Drawing.Size(62, 31);
            this.lbl品名2.TabIndex = 4;
            this.lbl品名2.Text = "綠茶";
            // 
            // lbl品名3
            // 
            this.lbl品名3.AutoSize = true;
            this.lbl品名3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl品名3.Location = new System.Drawing.Point(62, 245);
            this.lbl品名3.Name = "lbl品名3";
            this.lbl品名3.Size = new System.Drawing.Size(62, 31);
            this.lbl品名3.TabIndex = 5;
            this.lbl品名3.Text = "奶茶";
            // 
            // lbl品名4
            // 
            this.lbl品名4.AutoSize = true;
            this.lbl品名4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl品名4.Location = new System.Drawing.Point(62, 307);
            this.lbl品名4.Name = "lbl品名4";
            this.lbl品名4.Size = new System.Drawing.Size(62, 31);
            this.lbl品名4.TabIndex = 6;
            this.lbl品名4.Text = "花茶";
            // 
            // lbl品名5
            // 
            this.lbl品名5.AutoSize = true;
            this.lbl品名5.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl品名5.Location = new System.Drawing.Point(62, 375);
            this.lbl品名5.Name = "lbl品名5";
            this.lbl品名5.Size = new System.Drawing.Size(86, 31);
            this.lbl品名5.TabIndex = 7;
            this.lbl品名5.Text = "西瓜汁";
            // 
            // lbl售價1
            // 
            this.lbl售價1.AutoSize = true;
            this.lbl售價1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl售價1.Location = new System.Drawing.Point(269, 107);
            this.lbl售價1.Name = "lbl售價1";
            this.lbl售價1.Size = new System.Drawing.Size(42, 31);
            this.lbl售價1.TabIndex = 8;
            this.lbl售價1.Text = "20";
            // 
            // lbl售價2
            // 
            this.lbl售價2.AutoSize = true;
            this.lbl售價2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl售價2.Location = new System.Drawing.Point(269, 179);
            this.lbl售價2.Name = "lbl售價2";
            this.lbl售價2.Size = new System.Drawing.Size(42, 31);
            this.lbl售價2.TabIndex = 9;
            this.lbl售價2.Text = "25";
            // 
            // lbl售價3
            // 
            this.lbl售價3.AutoSize = true;
            this.lbl售價3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl售價3.Location = new System.Drawing.Point(269, 245);
            this.lbl售價3.Name = "lbl售價3";
            this.lbl售價3.Size = new System.Drawing.Size(42, 31);
            this.lbl售價3.TabIndex = 10;
            this.lbl售價3.Text = "30";
            // 
            // lbl售價4
            // 
            this.lbl售價4.AutoSize = true;
            this.lbl售價4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl售價4.Location = new System.Drawing.Point(269, 307);
            this.lbl售價4.Name = "lbl售價4";
            this.lbl售價4.Size = new System.Drawing.Size(42, 31);
            this.lbl售價4.TabIndex = 11;
            this.lbl售價4.Text = "35";
            // 
            // lbl售價5
            // 
            this.lbl售價5.AutoSize = true;
            this.lbl售價5.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl售價5.Location = new System.Drawing.Point(269, 375);
            this.lbl售價5.Name = "lbl售價5";
            this.lbl售價5.Size = new System.Drawing.Size(42, 31);
            this.lbl售價5.TabIndex = 12;
            this.lbl售價5.Text = "40";
            // 
            // tb杯數1
            // 
            this.tb杯數1.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb杯數1.Location = new System.Drawing.Point(447, 109);
            this.tb杯數1.Name = "tb杯數1";
            this.tb杯數1.Size = new System.Drawing.Size(98, 36);
            this.tb杯數1.TabIndex = 13;
            this.tb杯數1.TextChanged += new System.EventHandler(this.tb杯數1_TextChanged);
            // 
            // tb杯數2
            // 
            this.tb杯數2.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb杯數2.Location = new System.Drawing.Point(447, 176);
            this.tb杯數2.Name = "tb杯數2";
            this.tb杯數2.Size = new System.Drawing.Size(98, 36);
            this.tb杯數2.TabIndex = 14;
            this.tb杯數2.TextChanged += new System.EventHandler(this.tb杯數2_TextChanged);
            // 
            // tb杯數3
            // 
            this.tb杯數3.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb杯數3.Location = new System.Drawing.Point(447, 240);
            this.tb杯數3.Name = "tb杯數3";
            this.tb杯數3.Size = new System.Drawing.Size(98, 36);
            this.tb杯數3.TabIndex = 15;
            this.tb杯數3.TextChanged += new System.EventHandler(this.tb杯數3_TextChanged);
            // 
            // tb杯數4
            // 
            this.tb杯數4.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb杯數4.Location = new System.Drawing.Point(447, 302);
            this.tb杯數4.Name = "tb杯數4";
            this.tb杯數4.Size = new System.Drawing.Size(98, 36);
            this.tb杯數4.TabIndex = 16;
            this.tb杯數4.TextChanged += new System.EventHandler(this.tb杯數4_TextChanged);
            // 
            // tb杯數5
            // 
            this.tb杯數5.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb杯數5.Location = new System.Drawing.Point(447, 370);
            this.tb杯數5.Name = "tb杯數5";
            this.tb杯數5.Size = new System.Drawing.Size(98, 36);
            this.tb杯數5.TabIndex = 17;
            this.tb杯數5.TextChanged += new System.EventHandler(this.tb杯數5_TextChanged);
            // 
            // btn杯數1加
            // 
            this.btn杯數1加.AutoSize = true;
            this.btn杯數1加.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數1加.Location = new System.Drawing.Point(565, 110);
            this.btn杯數1加.Name = "btn杯數1加";
            this.btn杯數1加.Size = new System.Drawing.Size(38, 35);
            this.btn杯數1加.TabIndex = 18;
            this.btn杯數1加.Text = "+";
            this.btn杯數1加.UseVisualStyleBackColor = true;
            this.btn杯數1加.Click += new System.EventHandler(this.btn杯數1加_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Gold;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(370, 427);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 31);
            this.label14.TabIndex = 28;
            this.label14.Text = "折數";
            // 
            // tb折數
            // 
            this.tb折數.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb折數.Location = new System.Drawing.Point(447, 423);
            this.tb折數.Name = "tb折數";
            this.tb折數.Size = new System.Drawing.Size(98, 36);
            this.tb折數.TabIndex = 29;
            this.tb折數.TextChanged += new System.EventHandler(this.tb折數_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Gold;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(322, 484);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(110, 31);
            this.label15.TabIndex = 30;
            this.label15.Text = "訂單總價";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Gold;
            this.label16.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label16.Location = new System.Drawing.Point(250, 540);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(182, 31);
            this.label16.TabIndex = 31;
            this.label16.Text = "訂單折扣後總價";
            // 
            // lbl訂單總價
            // 
            this.lbl訂單總價.BackColor = System.Drawing.Color.AliceBlue;
            this.lbl訂單總價.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl訂單總價.Location = new System.Drawing.Point(459, 484);
            this.lbl訂單總價.Name = "lbl訂單總價";
            this.lbl訂單總價.Size = new System.Drawing.Size(166, 31);
            this.lbl訂單總價.TabIndex = 32;
            this.lbl訂單總價.Text = "0.0";
            // 
            // lbl折扣總價
            // 
            this.lbl折扣總價.BackColor = System.Drawing.Color.AliceBlue;
            this.lbl折扣總價.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl折扣總價.Location = new System.Drawing.Point(459, 540);
            this.lbl折扣總價.Name = "lbl折扣總價";
            this.lbl折扣總價.Size = new System.Drawing.Size(166, 31);
            this.lbl折扣總價.TabIndex = 33;
            this.lbl折扣總價.Text = "0.0\r\n";
            // 
            // btn列印訂購單
            // 
            this.btn列印訂購單.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn列印訂購單.Location = new System.Drawing.Point(27, 511);
            this.btn列印訂購單.Name = "btn列印訂購單";
            this.btn列印訂購單.Size = new System.Drawing.Size(190, 60);
            this.btn列印訂購單.TabIndex = 34;
            this.btn列印訂購單.Text = "列印訂購單";
            this.btn列印訂購單.UseVisualStyleBackColor = true;
            this.btn列印訂購單.Click += new System.EventHandler(this.btn列印訂購單_Click);
            // 
            // btn杯數2加
            // 
            this.btn杯數2加.AutoSize = true;
            this.btn杯數2加.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數2加.Location = new System.Drawing.Point(565, 175);
            this.btn杯數2加.Name = "btn杯數2加";
            this.btn杯數2加.Size = new System.Drawing.Size(38, 35);
            this.btn杯數2加.TabIndex = 35;
            this.btn杯數2加.Text = "+";
            this.btn杯數2加.UseVisualStyleBackColor = true;
            this.btn杯數2加.Click += new System.EventHandler(this.btn杯數2加_Click);
            // 
            // btn杯數3加
            // 
            this.btn杯數3加.AutoSize = true;
            this.btn杯數3加.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數3加.Location = new System.Drawing.Point(565, 241);
            this.btn杯數3加.Name = "btn杯數3加";
            this.btn杯數3加.Size = new System.Drawing.Size(38, 35);
            this.btn杯數3加.TabIndex = 36;
            this.btn杯數3加.Text = "+";
            this.btn杯數3加.UseVisualStyleBackColor = true;
            this.btn杯數3加.Click += new System.EventHandler(this.btn杯數3加_Click);
            // 
            // btn杯數4加
            // 
            this.btn杯數4加.AutoSize = true;
            this.btn杯數4加.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數4加.Location = new System.Drawing.Point(565, 302);
            this.btn杯數4加.Name = "btn杯數4加";
            this.btn杯數4加.Size = new System.Drawing.Size(38, 35);
            this.btn杯數4加.TabIndex = 37;
            this.btn杯數4加.Text = "+";
            this.btn杯數4加.UseVisualStyleBackColor = true;
            this.btn杯數4加.Click += new System.EventHandler(this.btn杯數4加_Click);
            // 
            // btn杯數5加
            // 
            this.btn杯數5加.AutoSize = true;
            this.btn杯數5加.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數5加.Location = new System.Drawing.Point(565, 368);
            this.btn杯數5加.Name = "btn杯數5加";
            this.btn杯數5加.Size = new System.Drawing.Size(38, 35);
            this.btn杯數5加.TabIndex = 38;
            this.btn杯數5加.Text = "+";
            this.btn杯數5加.UseVisualStyleBackColor = true;
            this.btn杯數5加.Click += new System.EventHandler(this.btn杯數5加_Click);
            // 
            // btn杯數1減
            // 
            this.btn杯數1減.AutoSize = true;
            this.btn杯數1減.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數1減.Location = new System.Drawing.Point(394, 110);
            this.btn杯數1減.Name = "btn杯數1減";
            this.btn杯數1減.Size = new System.Drawing.Size(38, 35);
            this.btn杯數1減.TabIndex = 39;
            this.btn杯數1減.Text = "-";
            this.btn杯數1減.UseVisualStyleBackColor = true;
            this.btn杯數1減.Click += new System.EventHandler(this.btn杯數1減_Click);
            // 
            // btn杯數2減
            // 
            this.btn杯數2減.AutoSize = true;
            this.btn杯數2減.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數2減.Location = new System.Drawing.Point(394, 174);
            this.btn杯數2減.Name = "btn杯數2減";
            this.btn杯數2減.Size = new System.Drawing.Size(38, 35);
            this.btn杯數2減.TabIndex = 40;
            this.btn杯數2減.Text = "-";
            this.btn杯數2減.UseVisualStyleBackColor = true;
            this.btn杯數2減.Click += new System.EventHandler(this.btn杯數2減_Click);
            // 
            // btn杯數3減
            // 
            this.btn杯數3減.AutoSize = true;
            this.btn杯數3減.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數3減.Location = new System.Drawing.Point(394, 241);
            this.btn杯數3減.Name = "btn杯數3減";
            this.btn杯數3減.Size = new System.Drawing.Size(38, 35);
            this.btn杯數3減.TabIndex = 41;
            this.btn杯數3減.Text = "-";
            this.btn杯數3減.UseVisualStyleBackColor = true;
            this.btn杯數3減.Click += new System.EventHandler(this.btn杯數3減_Click);
            // 
            // btn杯數4減
            // 
            this.btn杯數4減.AutoSize = true;
            this.btn杯數4減.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數4減.Location = new System.Drawing.Point(394, 303);
            this.btn杯數4減.Name = "btn杯數4減";
            this.btn杯數4減.Size = new System.Drawing.Size(38, 35);
            this.btn杯數4減.TabIndex = 42;
            this.btn杯數4減.Text = "-";
            this.btn杯數4減.UseVisualStyleBackColor = true;
            this.btn杯數4減.Click += new System.EventHandler(this.btn杯數4減_Click);
            // 
            // btn杯數5減
            // 
            this.btn杯數5減.AutoSize = true;
            this.btn杯數5減.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn杯數5減.Location = new System.Drawing.Point(394, 371);
            this.btn杯數5減.Name = "btn杯數5減";
            this.btn杯數5減.Size = new System.Drawing.Size(38, 35);
            this.btn杯數5減.TabIndex = 43;
            this.btn杯數5減.Text = "-";
            this.btn杯數5減.UseVisualStyleBackColor = true;
            this.btn杯數5減.Click += new System.EventHandler(this.btn杯數5減_Click);
            // 
            // btn第二件六折
            // 
            this.btn第二件六折.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn第二件六折.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn第二件六折.Location = new System.Drawing.Point(27, 427);
            this.btn第二件六折.Name = "btn第二件六折";
            this.btn第二件六折.Size = new System.Drawing.Size(117, 57);
            this.btn第二件六折.TabIndex = 44;
            this.btn第二件六折.Text = "同品項第二件六折";
            this.btn第二件六折.UseVisualStyleBackColor = false;
            this.btn第二件六折.Click += new System.EventHandler(this.btn第二件六折_Click);
            // 
            // btn買三送一
            // 
            this.btn買三送一.BackColor = System.Drawing.Color.Red;
            this.btn買三送一.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn買三送一.Location = new System.Drawing.Point(168, 427);
            this.btn買三送一.Name = "btn買三送一";
            this.btn買三送一.Size = new System.Drawing.Size(117, 57);
            this.btn買三送一.TabIndex = 45;
            this.btn買三送一.Text = "買三送一";
            this.btn買三送一.UseVisualStyleBackColor = false;
            this.btn買三送一.Click += new System.EventHandler(this.btn買三送一_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(694, 590);
            this.Controls.Add(this.btn買三送一);
            this.Controls.Add(this.btn第二件六折);
            this.Controls.Add(this.btn杯數5減);
            this.Controls.Add(this.btn杯數4減);
            this.Controls.Add(this.btn杯數3減);
            this.Controls.Add(this.btn杯數2減);
            this.Controls.Add(this.btn杯數1減);
            this.Controls.Add(this.btn杯數5加);
            this.Controls.Add(this.btn杯數4加);
            this.Controls.Add(this.btn杯數3加);
            this.Controls.Add(this.btn杯數2加);
            this.Controls.Add(this.btn列印訂購單);
            this.Controls.Add(this.lbl折扣總價);
            this.Controls.Add(this.lbl訂單總價);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tb折數);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.btn杯數1加);
            this.Controls.Add(this.tb杯數5);
            this.Controls.Add(this.tb杯數4);
            this.Controls.Add(this.tb杯數3);
            this.Controls.Add(this.tb杯數2);
            this.Controls.Add(this.tb杯數1);
            this.Controls.Add(this.lbl售價5);
            this.Controls.Add(this.lbl售價4);
            this.Controls.Add(this.lbl售價3);
            this.Controls.Add(this.lbl售價2);
            this.Controls.Add(this.lbl售價1);
            this.Controls.Add(this.lbl品名5);
            this.Controls.Add(this.lbl品名4);
            this.Controls.Add(this.lbl品名3);
            this.Controls.Add(this.lbl品名2);
            this.Controls.Add(this.lbl品名1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "iii冷飲店訂購單";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl品名1;
        private System.Windows.Forms.Label lbl品名2;
        private System.Windows.Forms.Label lbl品名3;
        private System.Windows.Forms.Label lbl品名4;
        private System.Windows.Forms.Label lbl品名5;
        private System.Windows.Forms.Label lbl售價1;
        private System.Windows.Forms.Label lbl售價2;
        private System.Windows.Forms.Label lbl售價3;
        private System.Windows.Forms.Label lbl售價4;
        private System.Windows.Forms.Label lbl售價5;
        private System.Windows.Forms.TextBox tb杯數1;
        private System.Windows.Forms.TextBox tb杯數2;
        private System.Windows.Forms.TextBox tb杯數3;
        private System.Windows.Forms.TextBox tb杯數4;
        private System.Windows.Forms.TextBox tb杯數5;
        private System.Windows.Forms.Button btn杯數1加;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tb折數;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl訂單總價;
        private System.Windows.Forms.Label lbl折扣總價;
        private System.Windows.Forms.Button btn列印訂購單;
        private System.Windows.Forms.Button btn杯數2加;
        private System.Windows.Forms.Button btn杯數3加;
        private System.Windows.Forms.Button btn杯數4加;
        private System.Windows.Forms.Button btn杯數5加;
        private System.Windows.Forms.Button btn杯數1減;
        private System.Windows.Forms.Button btn杯數2減;
        private System.Windows.Forms.Button btn杯數3減;
        private System.Windows.Forms.Button btn杯數4減;
        private System.Windows.Forms.Button btn杯數5減;
        private System.Windows.Forms.Button btn第二件六折;
        private System.Windows.Forms.Button btn買三送一;
    }
}

